#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "sort.h"

#define OBJECT_SIZE 100

typedef struct {
    uint32_t key;
    uint8_t value[96];
} BinaryObject;

int compare_objects(const void *a, const void *b) {
    const BinaryObject *objA = (const BinaryObject *)a;
    const BinaryObject *objB = (const BinaryObject *)b;
    
    
    if (objA->key < objB->key) return -1;
    else if (objA->key > objB->key) return 1;
    else return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s inputfile outputfile\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *input_filename = argv[1];
    const char *output_filename = argv[2];

    int input_fd = open(input_filename, O_RDONLY);
    if (input_fd == -1) {
        perror("Error opening input file");
        exit(EXIT_FAILURE);
    }

    struct stat st;
    if (fstat(input_fd, &st) == -1) {
        perror("Error getting file size");
        close(input_fd);
        exit(EXIT_FAILURE);
    }
    off_t file_size = st.st_size;

    size_t num_objects = file_size / OBJECT_SIZE;

    BinaryObject *objects = (BinaryObject *)malloc(num_objects * sizeof(BinaryObject));
    if (objects == NULL) {
        perror("Memory allocation failed");
        close(input_fd);
        exit(EXIT_FAILURE);
    }

    ssize_t bytes_read = read(input_fd, objects, file_size);
    if (bytes_read == -1) {
        perror("Error reading input file");
        free(objects);
        close(input_fd);
        exit(EXIT_FAILURE);
    }

    close(input_fd);

    qsort(objects, num_objects, sizeof(BinaryObject), compare_objects);

    int output_fd = open(output_filename, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (output_fd == -1) {
        perror("Error opening output file");
        free(objects);
        exit(EXIT_FAILURE);
    }

    
    for (size_t i = 0; i < num_objects; ++i) {
        ssize_t bytes_written = write(output_fd, &objects[i], sizeof(BinaryObject));
        if (bytes_written == -1) {
            perror("Error writing to output file");
            free(objects);
            close(output_fd);
            exit(EXIT_FAILURE);
        }
    }

    close(output_fd);
    free(objects);

    return 0;
}


