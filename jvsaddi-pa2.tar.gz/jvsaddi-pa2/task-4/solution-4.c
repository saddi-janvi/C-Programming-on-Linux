#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INPUT_LENGTH 1025

void parseAndPrintTokens(char *input) {
    
    char *token = strtok(input, " \t\n");

    
    while (token != NULL) {
        printf("%s\n", token);
        token = strtok(NULL, " \t\n");
    }
}

int main() {
   
    char input[MAX_INPUT_LENGTH];

    while (1) {
     
        if (fgets(input, sizeof(input), stdin) == NULL) {
            fprintf(stderr, "An error has occurred\n");
            exit(1);
        }

       
        if (strcmp(input, "exit\n") == 0) {
            break;
        }

        
        parseAndPrintTokens(input);
    }

    return 0;
}

