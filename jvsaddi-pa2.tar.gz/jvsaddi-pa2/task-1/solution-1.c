#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

void execute_command(char *command[]) {
    pid_t pid = fork();

    if (pid == -1) {
        perror("fork");
        exit(1);
    } else if (pid == 0) {
        // Child process
        if (execvp(command[0], command) == -1) {
            perror("execvp");
            exit(1);
        }
    } else {
        // Parent process
        int status;
        if (waitpid(pid, &status, 0) == -1) {
            perror("waitpid");
            exit(1);
        }

        if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
            fprintf(stderr, "An error has occurred\n");
            exit(1);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <file-path>\n", argv[0]);
        exit(1);
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("fopen");
        exit(1);
    }

    char line[1024];

    while (fgets(line, sizeof(line), file) != NULL) {
        // Remove the newline character
        line[strcspn(line, "\n")] = 0;

        char *command[4];
        command[0] = "sh";
        command[1] = "-c";
        command[2] = line;
        command[3] = NULL;

        execute_command(command);
    }

    fclose(file);

    return 0;
}

