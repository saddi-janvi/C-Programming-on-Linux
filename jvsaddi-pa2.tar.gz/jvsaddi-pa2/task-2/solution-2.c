#include <stdio.h>
#include <stdlib.h>
#include <string.h> 


int hexToDecimal(char hexDigit) {
    if (hexDigit >= '0' && hexDigit <= '9') {
        return hexDigit - '0';
    } else if (hexDigit >= 'a' && hexDigit <= 'f') {
        return hexDigit - 'a' + 10;
    } else if (hexDigit >= 'A' && hexDigit <= 'F') {
        return hexDigit - 'A' + 10;
    } else {
        
        fprintf(stderr, "Error: Invalid hexadecimal digit '%c'\n", hexDigit);
        exit(1);
    }
}


void hexToBinary(FILE *inputFile, FILE *outputFile) {
    char hexBuffer[1025];
    while (fgets(hexBuffer, sizeof(hexBuffer), inputFile) != NULL) {
       
        hexBuffer[strcspn(hexBuffer, "\n")] = '\0';

       
        for (int i = 0; hexBuffer[i] != '\0'; i++) {
            int decimalValue = hexToDecimal(hexBuffer[i]);

           
            for (int j = 3; j >= 0; j--) {
                int bit = (decimalValue >> j) & 1;
                fputc(bit + '0', outputFile);
            }
        }

     
        fputc('\n', outputFile);
    }
}

int main(int argc, char *argv[]) {
   
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <input_file> <output_file>\n", argv[0]);
        exit(1);
    }

    
    FILE *inputFile = fopen(argv[1], "r");
    if (inputFile == NULL) {
        perror("Error opening input file");
        exit(1);
    }

    
    FILE *outputFile = fopen(argv[2], "w");
    if (outputFile == NULL) {
        perror("Error opening output file");
        fclose(inputFile);
        exit(1);
    }

   
    hexToBinary(inputFile, outputFile);

   
    fclose(inputFile);
    fclose(outputFile);

    return 0;
}

