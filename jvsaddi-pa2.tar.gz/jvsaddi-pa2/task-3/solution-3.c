#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void binaryToHex(const char *binary, char *hexadecimal) {
    int binaryLen = strlen(binary);

    
    int padding = (4 - (binaryLen % 4)) % 4;
    int paddedLen = binaryLen + padding;

    
    char *paddedBinary = (char *)malloc(paddedLen + 1); 
    memset(paddedBinary, '0', padding);
    strcpy(paddedBinary + padding, binary);
    paddedBinary[paddedLen] = '\0';

    
    for (int i = 0; i < paddedLen; i += 4) {
        int chunkValue = 0;
        for (int j = 0; j < 4; j++) {
            chunkValue = (chunkValue << 1) | (paddedBinary[i + j] - '0');
        }

        if (chunkValue < 10) {
            hexadecimal[i / 4] = '0' + chunkValue;
        } else {
            hexadecimal[i / 4] = 'a' + (chunkValue - 10);
        }
    }
    hexadecimal[paddedLen / 4] = '\0';

    
    free(paddedBinary);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <input_file> <output_file>\n", argv[0]);
        exit(1);
    }

    FILE *inputFile = fopen(argv[1], "r");
    if (inputFile == NULL) {
        fprintf(stderr, "Error opening input file %s\n", argv[1]);
        exit(1);
    }

    FILE *outputFile = fopen(argv[2], "w");
    if (outputFile == NULL) {
        fprintf(stderr, "Error opening output file %s\n", argv[2]);
        fclose(inputFile);
        exit(1);
    }

    char *binary = malloc(1025); 
    char *hexadecimal = malloc(1025); 

    while (fgets(binary, 1025, inputFile) != NULL) {
        binary[strcspn(binary, "\n")] = '\0';  

        
        for (int i = 0; binary[i] != '\0'; i++) {
            if (binary[i] != '0' && binary[i] != '1') {
                fprintf(stderr, "Error: Invalid binary string in %s\n", argv[1]);
                fclose(inputFile);
                fclose(outputFile);
                free(binary);
                free(hexadecimal);
                exit(1);
            }
        }

        
        binaryToHex(binary, hexadecimal);
        fprintf(outputFile, "%s\n", hexadecimal);
    }

    fclose(inputFile);
    fclose(outputFile);

    free(binary);
    free(hexadecimal);

    return 0;
}

